var class_settings_weather =
[
    [ "SettingsWeather", "class_settings_weather.html#a30e7a6a72dc3d111571d861079124172", null ],
    [ "~SettingsWeather", "class_settings_weather.html#a95d87698b964e2169344667d755e2a0e", null ],
    [ "data_changed", "class_settings_weather.html#a8d83ab348c72671d280cd847f4ec3790", null ],
    [ "on_pushButton_save_clicked", "class_settings_weather.html#acc589a5b345c4c73abf3c6acf68d530e", null ],
    [ "settings", "class_settings_weather.html#af4c47cad7de83fb83f952f450db1dfb8", null ],
    [ "ui", "class_settings_weather.html#a8936a1e341da6ad702a673f844a3181c", null ]
];