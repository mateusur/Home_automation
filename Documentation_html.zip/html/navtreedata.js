var NAVTREE =
[
  [ "Home automation", "index.html", [
    [ "Dokumentacja aplikacji Home automation", "index.html", [
      [ "Wprowadzenie", "index.html#Wprowadzenie", null ],
      [ "Główne okno", "index.html#ChooseWindow", null ],
      [ "Okno kurnika", "index.html#Chickencoop", null ],
      [ "Okno nawadniania", "index.html#Watering", null ],
      [ "Okno pogody", "index.html#Weather", null ],
      [ "Okno ustawień pogody", "index.html#SettingsWeather", null ],
      [ "Okno ustawień klienta MQTT", "index.html#SettingsMQTT", null ],
      [ "Okno informacji o autorze", "index.html#Author", null ],
      [ "Dokumentacja", "index.html#Dokumentacja", null ]
    ] ],
    [ "Home_automation", "md__home_mateusz__downloads__home_automation__r_e_a_d_m_e.html", null ],
    [ "Przestrzenie nazw", null, [
      [ "Lista przestrzeni nazw", "namespaces.html", "namespaces" ]
    ] ],
    [ "Klasy", "annotated.html", [
      [ "Lista klas", "annotated.html", "annotated_dup" ],
      [ "Indeks klas", "classes.html", null ],
      [ "Hierarchia klas", "hierarchy.html", "hierarchy" ],
      [ "Składowe klas", "functions.html", [
        [ "Wszystko", "functions.html", null ],
        [ "Funkcje", "functions_func.html", null ],
        [ "Zmienne", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Pliki", null, [
      [ "Lista plików", "files.html", "files" ],
      [ "Składowe plików", "globals.html", [
        [ "Wszystko", "globals.html", null ],
        [ "Funkcje", "globals_func.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';