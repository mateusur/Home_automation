var annotated_dup =
[
    [ "Author", "class_author.html", "class_author" ],
    [ "Chickencoop", "class_chickencoop.html", "class_chickencoop" ],
    [ "ChooseWindow", "class_choose_window.html", "class_choose_window" ],
    [ "Droplet", "class_droplet.html", "class_droplet" ],
    [ "SettingsMQTT", "class_settings_m_q_t_t.html", "class_settings_m_q_t_t" ],
    [ "SettingsStream", "class_settings_stream.html", "class_settings_stream" ],
    [ "SettingsWeather", "class_settings_weather.html", "class_settings_weather" ],
    [ "Watering", "class_watering.html", "class_watering" ],
    [ "Weather", "class_weather.html", "class_weather" ]
];