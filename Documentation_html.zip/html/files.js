var files =
[
    [ "author.cpp", "author_8cpp.html", null ],
    [ "author.h", "author_8h.html", [
      [ "Author", "class_author.html", "class_author" ]
    ] ],
    [ "chickencoop.cpp", "chickencoop_8cpp.html", null ],
    [ "chickencoop.h", "chickencoop_8h.html", [
      [ "Chickencoop", "class_chickencoop.html", "class_chickencoop" ]
    ] ],
    [ "choosewindow.cpp", "choosewindow_8cpp.html", null ],
    [ "choosewindow.h", "choosewindow_8h.html", [
      [ "ChooseWindow", "class_choose_window.html", "class_choose_window" ]
    ] ],
    [ "droplet.cpp", "droplet_8cpp.html", null ],
    [ "droplet.h", "droplet_8h.html", [
      [ "Droplet", "class_droplet.html", "class_droplet" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "settingsmqtt.cpp", "settingsmqtt_8cpp.html", null ],
    [ "settingsmqtt.h", "settingsmqtt_8h.html", [
      [ "SettingsMQTT", "class_settings_m_q_t_t.html", "class_settings_m_q_t_t" ]
    ] ],
    [ "settingsstream.cpp", "settingsstream_8cpp.html", null ],
    [ "settingsstream.h", "settingsstream_8h.html", [
      [ "SettingsStream", "class_settings_stream.html", "class_settings_stream" ]
    ] ],
    [ "settingsweather.cpp", "settingsweather_8cpp.html", null ],
    [ "settingsweather.h", "settingsweather_8h.html", [
      [ "SettingsWeather", "class_settings_weather.html", "class_settings_weather" ]
    ] ],
    [ "watering.cpp", "watering_8cpp.html", null ],
    [ "watering.h", "watering_8h.html", [
      [ "Watering", "class_watering.html", "class_watering" ]
    ] ],
    [ "weather.cpp", "weather_8cpp.html", null ],
    [ "weather.h", "weather_8h.html", [
      [ "Weather", "class_weather.html", "class_weather" ]
    ] ]
];