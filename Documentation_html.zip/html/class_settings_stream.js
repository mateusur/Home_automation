var class_settings_stream =
[
    [ "SettingsStream", "class_settings_stream.html#a88488308bfe3bfafe3d7716c433dcc97", null ],
    [ "~SettingsStream", "class_settings_stream.html#a975e93521447144a6302e27114c86861", null ],
    [ "on_pushButton_save_clicked", "class_settings_stream.html#a90d1accf01fce23ef312e896f4ada3e4", null ],
    [ "settings", "class_settings_stream.html#a04a3bde8c2bec7a217817a219353cff8", null ],
    [ "ui", "class_settings_stream.html#a4499f2dd4aeac242323e850a5a20ac0b", null ]
];