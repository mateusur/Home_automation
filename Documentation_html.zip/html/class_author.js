var class_author =
[
    [ "Author", "class_author.html#a1b58cf613c87ed77d8154a3d6b2cf4db", null ],
    [ "~Author", "class_author.html#ae1d4db056b321487cf7c07a2045d4a2d", null ],
    [ "ui", "class_author.html#a3cf114352fa2a058234e0430f0c124f9", null ]
];