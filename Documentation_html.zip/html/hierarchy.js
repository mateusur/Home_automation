var hierarchy =
[
    [ "QDialog", null, [
      [ "Author", "class_author.html", null ],
      [ "Chickencoop", "class_chickencoop.html", null ],
      [ "SettingsMQTT", "class_settings_m_q_t_t.html", null ],
      [ "SettingsStream", "class_settings_stream.html", null ],
      [ "SettingsWeather", "class_settings_weather.html", null ],
      [ "Watering", "class_watering.html", null ],
      [ "Weather", "class_weather.html", null ]
    ] ],
    [ "QLabel", null, [
      [ "Droplet", "class_droplet.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "ChooseWindow", "class_choose_window.html", null ]
    ] ]
];